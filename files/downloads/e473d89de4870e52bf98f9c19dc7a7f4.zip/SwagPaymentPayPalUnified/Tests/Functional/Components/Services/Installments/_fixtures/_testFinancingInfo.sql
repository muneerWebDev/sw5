INSERT INTO `swag_payment_paypal_unified_financing_information` (`payment_id`, `fee_amount`, `total_cost`, `term`, `monthly_payment`)
VALUES ('TEST_PAYMENT_ID', 10.01, 1400.04, 12, 67.68);