// {block name="backend/paypal_unified/store/payment_sale"}
Ext.define('Shopware.apps.PaypalUnified.store.PaymentSale', {
    /**
     * @type { String }
     */
    extend: 'Ext.data.Store',

    /**
     * @type { String }
     */
    model: 'Shopware.apps.PaypalUnified.model.PaymentSale'
});
// {/block}
