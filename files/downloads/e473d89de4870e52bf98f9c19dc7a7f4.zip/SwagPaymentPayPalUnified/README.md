# SwagPaymentPayPalUnified

## An integration for shopware for many PayPal products

## License

The MIT License (MIT). Please see [License File](LICENSE) for more information.
